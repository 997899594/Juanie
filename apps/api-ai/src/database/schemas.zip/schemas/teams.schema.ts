import { pgTable, uuid, text, timestamp, index, uniqueIndex, varchar } from 'drizzle-orm/pg-core';
import { z } from 'zod';
import { organizations } from './organizations.schema';

export const teams = pgTable('teams', {
  id: uuid('id').primaryKey().defaultRandom(),
  
  // 组织ID：团队隶属的组织（企业/部门维度）
  organizationId: uuid('organization_id').references(() => organizations.id, { onDelete: 'cascade' }).notNull(),

  // 团队名称：在平台展示的友好名称
  name: text('name').notNull(),

  // 团队唯一标识：组织内唯一，用于URL或自动化引用
  slug: varchar('slug', { length: 100 }).notNull(),

  // 团队简介：用途说明、职责边界等
  description: text('description'),

  // 外部ID：可选，映射到外部IdP或GitLab Group编号
  externalId: text('external_id'),

  // 时间戳：创建与更新
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// 索引与唯一约束

// Zod 校验
export const insertTeamSchema = z.object({
  id: z.string().uuid().optional(),
  organizationId: z.string().uuid(),
  name: z.string(),
  slug: z.string(),
  description: z.string().optional(),
  externalId: z.string().optional(),
  createdAt: z.date().optional(),
  updatedAt: z.date().optional(),
});

export const selectTeamSchema = z.object({
  id: z.string().uuid(),
  organizationId: z.string().uuid(),
  name: z.string(),
  slug: z.string(),
  description: z.string().nullable(),
  externalId: z.string().nullable(),
  createdAt: z.date(),
  updatedAt: z.date(),
});
export const updateTeamSchema = selectTeamSchema.pick({
  name: true,
  slug: true,
  description: true,
  externalId: true,
}).partial();

export type Team = typeof teams.$inferSelect;
export type NewTeam = typeof teams.$inferInsert;
export type CreateTeam = z.infer<typeof insertTeamSchema>;
export type UpdateTeam = z.infer<typeof updateTeamSchema>;